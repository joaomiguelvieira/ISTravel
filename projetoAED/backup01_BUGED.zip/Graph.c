#include <stdlib.h>
#include "Graph.h"

struct Graph_
{
	int vertices;
	int bridges;
	LinkedList ** adjacencies;
};

struct Link_
{
	int vertice;
	Item weight;
};

static void ( * freeWeight )( Item );

int getVertice( Link * link )
{
	return ( link -> vertice );
}

Item getWeight( Link * link )
{
	return ( link -> weight );
}

Link * newLink( int city , Item weight )
{
	Link * new;
	
	new = ( Link * ) malloc( sizeof( Link ) );
	if( new == ( Link * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	( new -> vertice ) = city;
	( new -> weight ) = weight;
	
	return new;
}

void freeLink( Item link )
{
	freeWeight( ( ( Link * ) link ) -> weight );	
	free( link );
	
	return;
}

Graph * graphInit( int vertices , int bridges , void ( * freeWeight_ )( Item ) )
{
	Graph * new;
	int i;
	
	new = ( Graph * ) malloc( sizeof( Graph ) );
	if( new == ( Graph * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	( new -> vertices ) = vertices;
	( new -> bridges ) = bridges;
	freeWeight = freeWeight_;
	
	( new -> adjacencies ) = ( LinkedList ** ) malloc( vertices * sizeof( LinkedList * ) );
	if( ( new -> adjacencies ) == ( LinkedList ** ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	for( i = 0 ; i < vertices ; i++ )
		( new -> adjacencies )[i] = initList();
	
	return new;
}

void graphLinkInsert( Graph * graph , int vertice1 , int vertice2 , Item * weight )
{	
	( graph -> adjacencies )[vertice1] = insertUnsortedItemList( ( graph -> adjacencies )[vertice1] , ( Item ) newLink( vertice2 , weight[0] ) );
	( graph -> adjacencies )[vertice2] = insertUnsortedItemList( ( graph -> adjacencies )[vertice2] , ( Item ) newLink( vertice1 , weight[1] ) );
	
	return;
}

void freeGraph( Graph * graph )
{
	int i;
	
	for( i = 0 ; i < ( graph -> vertices ) ; i++ )
		freeList( ( graph -> adjacencies )[i] , freeLink );
		
	free( graph -> adjacencies );
	free( graph );
	
	return;
}

#define VERTICE( A ) ( ( ( Link * ) getItemNode( A ) ) -> vertice )
#define WEIGHT( A , B ) weigh( graph , A , weights[ A ] , ( Item )( ( Link * ) getItemNode( B ) ) )

static int * weights;

int * dijkstra( Graph * graph , int origin , int * shortest_path_tree , Item * bridges , int ( * weigh )( Graph * , int , int , Item ) )
{
	int * vertice , i;
	LinkedList * aux;
	Heap * priority_queue;
	int * heap_vertice;
	
	weights = ( int * ) malloc( ( graph -> vertices ) * sizeof( int ) );
	if( weights == ( int * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	priority_queue = initHeap( ( graph -> vertices ) , compareWeights , free );
	
	for( i = 0 ; i < ( graph -> vertices ) ; i++ )
	{
		shortest_path_tree[i] = -1;
		bridges[i] = ( Item ) NULL;
		weights[i] = INT_MAX;
		
		heap_vertice = ( int * ) malloc( sizeof( int ) );
		if( heap_vertice == ( int * ) NULL )
			makeException( ERROR_MEMORY_ALLOCATION );
		
		( * heap_vertice ) = i;
		insertElementHeap( priority_queue , ( Item ) heap_vertice );
	}
	
	weights[origin] = 0;
	
	heapSort( priority_queue );
	
	while( !isHeapEmpty( priority_queue ) )
	{		
		if( weights[ * ( vertice = ( int * ) removeMax( priority_queue ) ) ] != INT_MAX )
		{	
			for( aux = ( graph -> adjacencies )[ * vertice ] ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			{
				if( WEIGHT( ( * vertice ) , aux ) != INT_MAX && 
					( weights[ i = VERTICE( aux ) ] > weights[ * vertice ] + 
					WEIGHT( ( * vertice ) , aux ) ) )
				{
					bridges[i] = ( ( Link * ) getItemNode( aux ) ) -> weight;
					weights[i] = weights[ * vertice ] + WEIGHT( ( * vertice ) , aux );
					shortest_path_tree[i] = ( * vertice );
				}
				
				heapSort( priority_queue );
			}
		}
		
		free( vertice );
	}
	
	return weights;
}

int compareWeights( Item vertice1 , Item vertice2 )
{
	return ( weights[ ( * ( int * ) vertice1 ) ] < weights[ ( * ( int * ) vertice2 ) ] ) ? 1 : 0;
}

LinkedList * getAdjacencies( Graph * graph , int vertice )
{
	return ( graph -> adjacencies )[vertice];
}

int getNumberOfVertices( Graph * graph )
{
	return ( graph -> vertices );
}

void printGraph( Graph * graph )
{
	int i;
	LinkedList * aux;
	
	for( i = 0 ; i < graph -> vertices ; i++ )
	{
		printf( "[%d]: " , i );
		
		for( aux = ( graph -> adjacencies )[i] ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			printf( "%d " , ( ( Link * ) getItemNode( aux ) ) -> vertice );
		
		printf( "\n" );
	}
}

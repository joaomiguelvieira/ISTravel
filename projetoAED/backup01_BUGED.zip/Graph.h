#ifndef GraphHeader
#define GraphHeader

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "Defs.h"
#include "LinkedList.h"
#include "Heap.h"

typedef struct Graph_ Graph;

typedef struct Link_ Link;

Graph * graphInit( int vertices , int bridges , void ( * freeWeight )( Item ) );

void graphLinkInsert( Graph * graph , int city1 , int city2 , Item * weight );

void freeGraph( Graph * graph );

Link * newLink( int city , Item weight );

void freeLink( Item link );

int * dijkstra( Graph * graph , int origin , int * shortest_path_tree , Item * bridges , int ( * weigh )( Graph * , int , int , Item ) );

int compareWeights( Item vertice1 , Item vertice2 );

int getVertice( Link * link );

Item getWeight( Link * link );

LinkedList * getAdjacencies( Graph * graph , int vertice );

int getNumberOfVertices( Graph * graph );

void printGraph( Graph * graph );

#endif

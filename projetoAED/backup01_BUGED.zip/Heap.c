#include "Heap.h"

struct Heap_
{
	int ( * less )( Item , Item );
	void ( * freeStructure )( Item );
	int n_elements;
	int size;
	Item * heap_data;
};

void fixUp( Heap * heap , int i )
{
	Item aux;
	
	while( ( i > 0 ) && ( heap -> less )( ( heap -> heap_data )[ ( i - 1 ) / 2 ] , ( heap -> heap_data )[i] ) )
	{
		aux = ( heap -> heap_data )[i];
		( heap -> heap_data )[i] = ( heap -> heap_data )[ ( i - 1 ) / 2 ];
		( heap -> heap_data )[ ( i - 1 ) / 2 ] = aux;
		i = ( i - 1 ) / 2;
	}
	
	return;
}

void fixDown( Heap * heap , int i )
{
	int j;
	Item aux;
	
	while( ( 2 * i + 1 ) < ( heap -> n_elements ) )
	{
		j = 2 * i + 1;
		
		if( ( ( j + 1 ) < ( heap -> n_elements ) ) && ( heap -> less )( ( heap -> heap_data )[j] , ( heap -> heap_data )[ j + 1 ] ) )
			j++;
		
		if( !( heap -> less )( ( heap -> heap_data )[i] , ( heap -> heap_data )[j] ) )
			break;
			
		aux = ( heap -> heap_data )[i];
		( heap -> heap_data )[i] = ( heap -> heap_data )[j];
		( heap -> heap_data )[j] = aux;
		i = j;
	}
	
	return;
}

Heap * initHeap( int size , int ( * less )( Item , Item ) , void ( * freeStructure )( Item ) )
{
	Heap * new;
	
	new = ( Heap * ) malloc( sizeof( Heap ) );
	if( new == ( Heap * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	( new -> n_elements ) = 0;
	( new -> size ) = size;
	( new -> freeStructure ) = freeStructure;
	( new -> less ) = less;
	
	( new -> heap_data ) = ( Item * ) malloc( size * sizeof( Item ) );
	if( ( new -> heap_data ) == ( Item * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	return new;
}

void freeHeap( Heap * heap )
{
	int i;
	
	for( i = 0 ; i < ( heap -> n_elements ) ; i++ )
		( heap -> freeStructure )( ( heap -> heap_data )[i] );
	
	free( heap -> heap_data );
	free( heap );
	
	return;
}

int insertElementHeap( Heap * heap , Item element )
{
	if( ( heap -> n_elements ) == ( heap -> size ) )
		return 0;
	
	( heap -> heap_data )[ ( heap -> n_elements ) ] = element;
	( heap -> n_elements )++;
	
	fixUp( heap , ( ( heap -> n_elements ) -1 ) );
	
	return 1;
}

int directInsertElementHeap( Heap * heap , Item element )
{
	if( ( heap -> n_elements ) == ( heap -> size ) )
		return 0;
	
	( heap -> heap_data )[ ( heap -> n_elements ) ] = element;
	( heap -> n_elements )++;
	
	return 1;
}

void modifyElementHeap( Heap * heap , int i , Item new )
{
	if( i > ( heap -> n_elements ) - 1 )
		makeException( ERROR_OUT_OF_RANGE );
	
	( heap -> freeStructure )( ( heap -> heap_data )[i] );
	( heap -> heap_data )[i] = new;
	
	/* Compares the new value with the previous one to find out if it
	 * has to do fixUp or fixDown. */
	if( ( heap -> less )( new , ( heap -> heap_data )[i] ) )
		fixDown( heap , i );
	else
		fixUp( heap , i );
	
	return;
}

Item removeMax( Heap * heap )
{
	Item aux;
	
	if( ( heap -> n_elements ) > 0 )
	{
		aux = ( heap -> heap_data )[0];
		( heap -> heap_data )[0] = ( heap -> heap_data )[ ( heap -> n_elements ) - 1 ];
		( heap -> heap_data )[ ( heap -> n_elements ) - 1 ] = ( Item ) NULL;
		( heap -> n_elements )--;
		
		fixDown( heap , 0 );
		
		return aux;
	}
	else
		return ( Item ) NULL;
}

void cleanHeap( Heap * heap )
{
	int i;
	
	for( i = 0 ; i < ( heap -> n_elements ) ; i++ )
		( heap -> freeStructure )( ( heap -> heap_data )[i] );
	
	( heap -> n_elements ) = 0;
	
	return;
}

int verifyHeap( Heap * heap )
{
	int i;
	
	for( i = ( ( heap -> n_elements ) - 1 ) ; i > 0 ; i-- )
		if( ( heap -> less )( ( heap -> heap_data )[ ( i - 1 ) / 2 ] , ( heap -> heap_data )[i] ) )
			return 0;
	
	return 1;
}

void heapify( Heap * heap )
{
	int i;
	
	for( i = ( ( ( heap -> n_elements ) - 1 ) / 2 ) ; i >= 0 ; i-- )
		fixDown( heap , i );
	
	return;
}

void heapSort( Heap * heap )
{
	int backup = ( heap -> n_elements );
	Item aux;
	
	heapify( heap );
	
	( heap -> n_elements )--;
	
	while( ( heap -> n_elements ) > 0 )
	{
		aux = ( heap -> heap_data )[0];
		( heap -> heap_data )[0] = ( heap -> heap_data )[ ( heap -> n_elements ) - 1 ];
		( heap -> heap_data )[ ( heap -> n_elements ) - 1 ] = aux;
		
		( heap -> n_elements )--;
		
		fixDown( heap , 0 );
	}
	
	( heap -> n_elements ) = backup;
	
	return;
}

int isHeapEmpty( Heap * heap )
{
	return ( ( heap -> n_elements ) == 0 ) ? 1 : 0;
}

void printIntegersHeap( Heap * heap )
{
	int i;
	
	for( i = 0 ; i < ( heap -> n_elements ) ; i++ )
		printf( "%d " , * ( int * )( heap -> heap_data )[i] );
		
	printf( "\n" );
	
	return;
}

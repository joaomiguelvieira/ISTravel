#ifndef HeapHeader
#define HeapHeader

#include <stdlib.h>
#include <stdio.h>
#include "Defs.h"

typedef struct Heap_ Heap;


void cleanHeap( Heap * heap );

int directInsertElementHeap( Heap * heap , Item element );

void fixDown( Heap * heap , int i );

void fixUp( Heap * heap , int i );

void freeHeap( Heap * heap );

void heapSort( Heap * heap );

void heapify( Heap * heap );

Heap * initHeap( int size , int ( * less )( Item , Item ) , void ( * freeStructure )( Item ) );

int insertElementHeap( Heap * heap , Item element );

void modifyElementHeap( Heap * heap , int i , Item new );

Item removeMax( Heap * heap );

int verifyHeap( Heap * heap );

int isHeapEmpty( Heap * heap );

void printIntegersHeap( Heap * heap );

#endif

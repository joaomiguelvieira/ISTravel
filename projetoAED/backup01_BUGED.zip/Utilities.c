/**
 * @file Utilities.c
 * @brief This file contains the implementation of the interface 
 * 		"Utilities". This interface in nothing else than some general
 * 		operations executed in the main program that are descripted here
 * 		in order to abstract the code.
 * 
 * @author João Miguel Morgado Pereira Vieira, nº 79191, MEEC
 * @author Tomás Miguel Donga Cardoso, nº 79007, MEEC
 * 
 * @date November 18th, 2014
 * */

#include "Utilities.h"

void usage( char ** argv )
{
	fprintf( stderr , "[USAGE]: %s <map_file>.map <client_file>.cli\n" , argv[0] );
		
	makeException( ERROR_USAGE ); 
}

int equalExtentions( char * string , char * extention )
{
	return ( strcmp( ( string + ( strlen( string ) - strlen( extention ) ) ) , extention ) == 0 ) ? 1 : 0;
}

char * saveString( char * string )
{
	char * saved_string;
	
	saved_string = ( char * ) malloc( ( strlen( string ) + 1 ) * sizeof( char ) );
	if( saved_string == ( char * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	strcpy( saved_string , string );
	
	return saved_string;
}

char * getOutputFileName( char * input_filename , char * input_file_extention , char * output_file_extention )
{
	char * output_filename;
	char aux[LINEWIDTH];
	
	output_filename = ( char * ) malloc( ( strlen( input_filename ) - strlen( input_file_extention ) + strlen( output_file_extention ) + 1 ) * sizeof( char ) );
	if( output_filename == ( char * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	strcpy( aux , input_filename );
	
	aux[ strlen( input_filename ) - strlen( input_file_extention ) ] = '\0';
	
	strcpy( output_filename , aux );
	strcat( output_filename , output_file_extention );
	
	return output_filename;
}

Graph * getMapFromFile( char * map_filename )
{
	FILE * file_map;
	
	Graph * map;
	
	char line[LINEWIDTH];
	
	int vertices;
	int bridges;
	
	int city1;
	int city2;
	
	Bridge * weight[2];
	char transportation_s[LINEWIDTH];
	int transportation;
	int time;
	int cost;
	int first_travel;
	int no_more_travels;
	int period;
	
	file_map = fopen( map_filename , "r" );
	if( file_map == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	fgets( line , LINEWIDTH , file_map );
	if( sscanf( line , "%d %d" , &vertices , &bridges ) != 2 )
		makeException( ERROR_CAMP_NOT_EXPECTED );
		
	map = graphInit( vertices , bridges , freeBridge );
	
	for( ; bridges > 0 ; bridges-- )
	{
		fgets( line , LINEWIDTH , file_map );
		
		if( sscanf( line , "%d %d %s %d %d %d %d %d" , &city1 , &city2 , transportation_s , &time , &cost , &first_travel , &no_more_travels , &period ) != 8 )
			makeException( ERROR_CAMP_NOT_EXPECTED );
		
		transportation = getTransportationFromString( transportation_s );
		
		weight[0] = newBridge( transportation , time , cost , first_travel , no_more_travels , period );
		weight[1] = newBridge( transportation , time , cost , first_travel , no_more_travels , period );
		
		graphLinkInsert( map , ( city1 - 1 ) , ( city2 - 1 ) , ( Item ) weight );
	}
	
	/* The program already read the file and loaded the map to the 
	 * system. We are ready to close the file. */
	fclose( file_map );
	
	return map;
}

static int optimization = 0;
static int restriction_1 = 0;
static int v_restriction_1 = 0;
static int restriction_2 = 0;
static int v_restriction_2 = 0;
static int ready_from;

void computeBestPath( Graph * map , char * client_filename , char * output_filename )
{
	FILE * client_file;
	FILE * output_file;
	
	char line[ LINEWIDTH ];
	
	int n_clients;
	int i;
	
	int client;
	int origin;
	int destination;
	int n_restriction;
	
	char optimization_string[ LINEWIDTH ];
	char restriction_1_string[ LINEWIDTH ];
	char v_restriction_1_string[ LINEWIDTH ];
	char restriction_2_string[ LINEWIDTH ];
	char v_restriction_2_string[ LINEWIDTH ];
	
	int * shortest_path_tree;
	Bridge ** bridges;
	
	int * weights;
	
	shortest_path_tree = ( int * ) malloc( getNumberOfVertices( map ) * sizeof( int ) );
	if( shortest_path_tree == ( int * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	bridges = ( Bridge ** ) malloc( getNumberOfVertices( map ) * sizeof( Bridge * ) );
	if( bridges == ( Bridge ** ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	client_file = fopen( client_filename , "r" );
	if( client_file == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	output_file = fopen( output_filename , "w" );
	if( output_file == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	fgets( line , LINEWIDTH , client_file );
	if( sscanf( line , "%d" , &n_clients ) != 1 )
		makeException( ERROR_CAMP_NOT_EXPECTED );
	
	for( i = 0 ; i < n_clients ; i++ )
	{	
		fgets( line , LINEWIDTH , client_file );
		
		if( sscanf( line , "%d %d %d %d %s %d %s %s %s %s" , 
			&client , &origin , &destination , &ready_from , 
			optimization_string , &n_restriction , restriction_1_string , 
			v_restriction_1_string , restriction_2_string , 
			v_restriction_2_string ) != ( 6 + n_restriction * 2 ) )
				makeException( ERROR_CAMP_NOT_EXPECTED );
		
		origin--;
		destination--;
		optimization = getOptimizationCriterium( optimization_string );
		
		if( n_restriction > 0 )
		{
			restriction_1 = getRestriction( restriction_1_string );
			if( restriction_1 != A1 )
				v_restriction_1 = atoi( v_restriction_1_string );
			else
				v_restriction_1 = getTransportationFromString( v_restriction_1_string );
			
			if( n_restriction == 2 )
			{	
				restriction_2 = getRestriction( restriction_2_string );
				if( restriction_2 != A1 )
					v_restriction_2 = atoi( v_restriction_2_string );
				else
					v_restriction_2 = getTransportationFromString( v_restriction_2_string );
			}
		}
		
		weights = dijkstra( map , origin , shortest_path_tree , ( Item * ) bridges , weigh );
		
		fprintf( output_file , "%d " , client );
		
		if( shortest_path_tree[destination] == -1 )
			fprintf( output_file , "-1" );
		else
		{
			printPath( output_file , shortest_path_tree , bridges , destination , origin );
			
			switch( optimization )
			{
				case TIME:
					fprintf( output_file , "%d " , weights[destination] );
					fprintf( output_file , "%d " , getTotalPrice( shortest_path_tree , bridges , origin , destination ) );
					break;
				case COST:
					fprintf( output_file , "%d " , getTotalTime( shortest_path_tree , bridges , origin , destination ) );
					fprintf( output_file , "%d " , weights[destination] );
					break;
				default:
					makeException( ERROR_CAMP_NOT_EXPECTED );
			}
		}
		
		fprintf( output_file , "\n" );
	}
	
	fclose( output_file );
	
	return;
}

int getTotalPrice( int * shortest_path_tree , Bridge ** bridges , int origin , int destination )
{
	int i , total_price = 0;
	
	for( i = destination ; i != origin ; i = shortest_path_tree[i] )
		total_price += getPrice( bridges[i] );
	
	return total_price;
}

int getTotalTime( int * shortest_path_tree , Bridge ** bridges , int origin , int destination )
{
	int total_time;
	Link * aux;
	
	if( origin == destination )
		return 0;
	
	total_time = getTotalTime( shortest_path_tree , bridges , origin , shortest_path_tree[destination] );
	
	aux = newLink( destination , bridges[destination] );
	
	return getTime( total_time % DAY_TIME , aux ) + total_time;
}

int weigh( Graph * graph , int origin , int counter , Item link )
{
	int weight = 0;
	int A[3] = { INT_MAX , INT_MAX , INT_MAX };
	LinkedList * aux;
	
	switch( restriction_1 )
	{
		case A1:
			A[0] = v_restriction_1;
			break;
		case A2:
			A[1] = v_restriction_1;
			break;
		case A3:
			A[2] = v_restriction_1;
			break;
		default:
			;
	}
	
	switch( restriction_2 )
	{
		case A1:
			A[0] = v_restriction_2;
			break;
		case A2:
			A[1] = v_restriction_2;
			break;
		case A3:
			A[2] = v_restriction_2;
			break;
		default:
			;
	}
	
	switch( optimization )
	{
		case TIME:
			weight = getTime( counter , link );
			
			for( aux = getAdjacencies( graph , origin ) ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			{
				if( ( getVertice( ( Link * ) link ) == getVertice( ( Link * ) getItemNode( aux ) ) ) && 
					( getTime( counter , link ) < weight ) &&
					( getTransportation( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) != A[0] ) &&
					( getDuration( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) < A[1] ) &&
					( getPrice( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) < A[2] ) )
					weight = INT_MAX;
			}
			break;
		case COST:
			weight = getPrice( ( Bridge * ) getWeight( ( Link * ) link ) );
		
			for( aux = getAdjacencies( graph , origin ) ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			{
				if( ( getVertice( ( Link * ) link ) == getVertice( ( Link * ) getItemNode( aux ) ) ) && 
					( getPrice( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) < weight ) &&
					( getTransportation( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) != A[0] ) &&
					( getDuration( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) < A[1] ) &&
					( getPrice( ( Bridge * ) getWeight( ( Link * ) getItemNode( aux ) ) ) < A[2] ) )
					weight = INT_MAX;
			}
			break;
		default:
			makeException( ERROR_UNKNOWN );
	}
	
	if( ( getTransportation( ( Bridge * ) getWeight( ( Link * ) link ) ) == A[0] ) ||
		( getDuration( ( Bridge * ) getWeight( ( Link * ) link ) ) > A[1] ) ||
		( getPrice( ( Bridge * ) getWeight( ( Link * ) link ) ) > A[2] ) )
		weight = INT_MAX;
	
	return weight;
}

int getTime( int counter , Link * link )
{
	int total_time;
	int wait_and_duration = 0;
	int aux , i;
	
	total_time = ready_from + counter;
	
	while( 1 )
	{	
		aux = ( total_time + wait_and_duration ) % DAY_TIME;
		
		if( aux > getNoMoreTravels( ( Bridge * ) getWeight( ( Link * ) link ) ) )
		{
			wait_and_duration += ( DAY_TIME - aux );
			aux = ( total_time + wait_and_duration ) % DAY_TIME;
		}
		
		if( aux < getFirstTravel( ( Bridge * ) getWeight( ( Link * ) link ) ) )
			wait_and_duration += getFirstTravel( ( Bridge * ) getWeight( ( Link * ) link ) ) - aux;
			
		for( i = getFirstTravel( ( Bridge * ) getWeight( ( Link * ) link ) ) ;
			i < aux ; i += getPeriod( ( Bridge * ) getWeight( ( Link * ) link ) ) );
		
		wait_and_duration += ( i - aux );
		
		if( i <= getNoMoreTravels( ( Bridge * ) getWeight( ( Link * ) link ) ) )
			break;
	}
	
	return wait_and_duration + getDuration( ( Bridge * ) getWeight( ( Link * ) link ) );
}

void printPath( FILE * output_file , int * shortest_path_tree , Bridge ** bridges , int destination , int origin )
{
	if( destination == origin )
	{
		fprintf( output_file , "%d " , ( origin + 1 ) );
		return;
	}
	else
		printPath( output_file , shortest_path_tree , bridges , shortest_path_tree[destination] , origin );
	
	switch( getTransportation( bridges[destination] ) )
	{
		case PLANE:
			fprintf( output_file , "aviao " );
			break;
		case BOAT:
			fprintf( output_file , "barco " );
			break;
		case TRAIN:
			fprintf( output_file , "comboio " );
			break;
		case BUS:
			fprintf( output_file , "autocarro " );
			break;
		default:
			makeException( ERROR_CAMP_NOT_EXPECTED );
	}
	
	fprintf( output_file , "%d " , ( destination + 1 ) );
	
	return;
}

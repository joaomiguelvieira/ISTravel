#ifndef BridgeHeader
#define BridgeHeader

#include <stdlib.h>
#include <stdio.h>
#include "Defs.h"

typedef struct Bridge_ Bridge;

Bridge * newBridge( int transportation , int duration , int price , int first_travel , int no_more_travels , int period );

void freeBridge( Item bridge );

/* Getters */

int getTransportation( Bridge * bridge );

int getDuration( Bridge * bridge );

int getPrice( Bridge * bridge );

int getFirstTravel( Bridge * bridge );

int getNoMoreTravels( Bridge * bridge );

int getPeriod( Bridge * bridge );

#endif

#include <stdlib.h>
#include <stdio.h>
#include "Defs.h"

#define EXCH( A , B ) { int third; third = A; A = B; B = third; }

typedef struct Heap_ Heap;

void CleanHeap( Heap * h );

int Direct_Insert( Heap * h , int element );

void FixDown( Heap * h , int k );

void FixUp( Heap * h , int k );

void FreeHeap( Heap * h );

void HeapSort( Heap * h );

void Heapify( Heap * h );

int Insert( Heap * h , int element );

void Modify( Heap * h , int index , int newvalue );

Heap * NewHeap( int size , int * priority );

int RemoveMax( Heap * h );

int VerifyHeap( Heap * h );

void incPriority( Heap * heap , int index );

int isHeapEmpty( Heap * heap );

/**
 * @file Utilities.c
 * @brief This file contains the implementation of the interface 
 * 		"Utilities". This interface in nothing else than some general
 * 		operations executed in the main program that are descripted here
 * 		in order to abstract the code.
 * 
 * @author João Miguel Morgado Pereira Vieira, nº 79191, MEEC
 * @author Tomás Miguel Donga Cardoso, nº 79007, MEEC
 * 
 * @date November 18th, 2014
 * */

#include "Utilities.h"

void usage( char ** argv )
{
	fprintf( stderr , "[USAGE]: %s <map_file>.map <client_file>.cli\n" , argv[0] );
		
	makeException( ERROR_USAGE ); 
}

int equalExtentions( char * string , char * extention )
{
	return ( strcmp( ( string + ( strlen( string ) - strlen( extention ) ) ) , extention ) == 0 ) ? 1 : 0;
}

char * saveString( char * string )
{
	char * saved_string;
	
	saved_string = ( char * ) malloc( ( strlen( string ) + 1 ) * sizeof( char ) );
	if( saved_string == ( char * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	strcpy( saved_string , string );
	
	return saved_string;
}

char * getOutputFileName( char * input_filename , char * input_file_extention , char * output_file_extention )
{
	char * output_filename;
	char aux[LINEWIDTH];
	
	output_filename = ( char * ) malloc( ( strlen( input_filename ) - strlen( input_file_extention ) + strlen( output_file_extention ) + 1 ) * sizeof( char ) );
	if( output_filename == ( char * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	strcpy( aux , input_filename );
	
	aux[ strlen( input_filename ) - strlen( input_file_extention ) ] = '\0';
	
	strcpy( output_filename , aux );
	strcat( output_filename , output_file_extention );
	
	return output_filename;
}

Graph * getMapFromFile( char * map_filename )
{
	FILE * file_map;
	
	Graph * map;
	
	char line[LINEWIDTH];
	
	int vertices;
	int bridges;
	
	int city1;
	int city2;
	
	int i , j;
	
	Bridge * weight;
	char transportation_s[ LINEWIDTH ];
	int transportation;
	int time;
	int cost;
	int first_travel;
	int no_more_travels;
	int period;
	
	LinkedList *** adjacencies_matrix;
	
	file_map = fopen( map_filename , "r" );
	if( file_map == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	fgets( line , LINEWIDTH , file_map );
	if( sscanf( line , "%d %d" , &vertices , &bridges ) != 2 )
		makeException( ERROR_CAMP_NOT_EXPECTED );
		
	adjacencies_matrix = ( LinkedList *** ) malloc( vertices * sizeof( LinkedList ** ) );
	if( adjacencies_matrix == ( LinkedList *** ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	for( i = 0 ; i < vertices ; i++ )
	{
		adjacencies_matrix[i] = ( LinkedList ** ) malloc( vertices * sizeof( LinkedList * ) );
		if( adjacencies_matrix[i] == ( LinkedList ** ) NULL )
			makeException( ERROR_MEMORY_ALLOCATION );
		
		for( j = 0 ; j < vertices ; j++ )
			adjacencies_matrix[i][j] = ( LinkedList * ) NULL;
	}
	
	for( i = bridges ; i > 0 ; i-- )
	{
		fgets( line , LINEWIDTH , file_map );
		
		if( sscanf( line , "%d %d %s %d %d %d %d %d" , &city1 , &city2 , transportation_s , &time , &cost , &first_travel , &no_more_travels , &period ) != 8 )
			makeException( ERROR_CAMP_NOT_EXPECTED );
		
		city1--;
		city2--;
		
		transportation = getTransportationFromString( transportation_s );
		
		weight = newBridge( transportation , time , cost , first_travel , no_more_travels , period );
		
		if( ( adjacencies_matrix[city1][city2] == ( LinkedList * ) NULL ) )
			adjacencies_matrix[city2][city1] = adjacencies_matrix[city1][city2] = initList();
			
		adjacencies_matrix[city2][city1] = adjacencies_matrix[city1][city2] = insertUnsortedItemList( adjacencies_matrix[city1][city2] , ( Item ) weight );
	}
		
	map = graphInit( vertices , bridges , freeWeight );
	
	for( i = 0 ; i < vertices ; i++ )
		for( j = 0 ; j < i ; j++ )
			if( adjacencies_matrix[i][j] != ( LinkedList * ) NULL )
				graphLinkInsert( map , i , j , ( Item ) adjacencies_matrix[i][j] );
	
	for( i = 0 ; i < vertices ; i++ )
		free( adjacencies_matrix[i] );
	
	free( adjacencies_matrix );
	
	/* The program already read the file and loaded the map to the 
	 * system. We are ready to close the file. */
	fclose( file_map );
	
	return map;
}

static int optimization = 0;
static int ready_from;
static int restrictions_A[3];
static int restrictions_B[2];

void computeBestPath( Graph * map , char * client_filename , char * output_filename )
{
	FILE * client_file;
	FILE * output_file;
	
	char line[ LINEWIDTH ];
	
	int n_clients;
	int i;
	
	int client;
	int origin;
	int destination;
	int n_restriction;
	
	char optimization_string[ LINEWIDTH ];
	char restriction_1_string[ LINEWIDTH ];
	char v_restriction_1_string[ LINEWIDTH ];
	char restriction_2_string[ LINEWIDTH ];
	char v_restriction_2_string[ LINEWIDTH ];
	
	int * shortest_path_tree;
	Bridge ** bridges;
	
	int * weights;
	
	shortest_path_tree = ( int * ) malloc( getNumberOfVertices( map ) * sizeof( int ) );
	if( shortest_path_tree == ( int * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	bridges = ( Bridge ** ) malloc( getNumberOfVertices( map ) * sizeof( Bridge * ) );
	if( bridges == ( Bridge ** ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	client_file = fopen( client_filename , "r" );
	if( client_file == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	output_file = fopen( output_filename , "w" );
	if( output_file == ( FILE * ) NULL )
		makeException( ERROR_FILE_MAN );
	
	fgets( line , LINEWIDTH , client_file );
	if( sscanf( line , "%d" , &n_clients ) != 1 )
		makeException( ERROR_CAMP_NOT_EXPECTED );
	
	for( i = 0 ; i < n_clients ; i++ )
	{	
		fgets( line , LINEWIDTH , client_file );
		
		if( sscanf( line , "%d %d %d %d %s %d %s %s %s %s" , 
			&client , &origin , &destination , &ready_from , 
			optimization_string , &n_restriction , restriction_1_string , 
			v_restriction_1_string , restriction_2_string , 
			v_restriction_2_string ) != ( 6 + n_restriction * 2 ) )
				makeException( ERROR_CAMP_NOT_EXPECTED );
		
		origin--;
		destination--;
		optimization = getOptimizationCriterium( optimization_string );
		
		switch( n_restriction )
		{
			case 2:
				defineRestriction( restriction_2_string , v_restriction_2_string );
			case 1:
				defineRestriction( restriction_1_string , v_restriction_1_string );
				break;
			default:
				restrictions_A[0] = restrictions_A[1] = restrictions_A[2] = INT_MAX;
				restrictions_B[0] = restrictions_B[1] = INT_MAX;
				;
		}
		
		#ifdef PROGRESSION
			switch( optimization )
			{
				case TIME:
					printf( "TIME: " );
					break;
				case COST:
					printf( "COST: " );
				default:
					;
			}
			
			printf( "Solving client %d (%d <---> %d)\n" , client , ( origin + 1 ) , ( destination + 1 ) );
		#endif
		
		weights = dijkstra( map , origin , shortest_path_tree , ( Item * ) bridges , weigh );
		
		fprintf( output_file , "%d " , client );
		
		if( shortest_path_tree[destination] == -1 || !followRestrictionsB( weights[destination] ) )
			fprintf( output_file , "-1" );
		else
		{
			printPath( output_file , shortest_path_tree , bridges , destination , origin );
			
			switch( optimization )
			{
				case TIME:
					fprintf( output_file , "%d " , weights[destination] );
					fprintf( output_file , "%d " , getTotalPrice( shortest_path_tree , bridges , origin , destination ) );
					break;
				case COST:
					fprintf( output_file , "%d " , getTotalTime( shortest_path_tree , bridges , origin , destination ) );
					fprintf( output_file , "%d " , weights[destination] );
					break;
				default:
					makeException( ERROR_CAMP_NOT_EXPECTED );
			}
		}
		
		fprintf( output_file , "\n" );
		
		free( weights );
	}
	free( shortest_path_tree );
	free( bridges );
	fclose( client_file );
	fclose( output_file );
	
	return;
}

void freeWeight( Item weight )
{
	freeList( ( LinkedList * ) weight , freeBridge );
	
	return;
}

void defineRestriction( char * restriction , char * value )
{
	restrictions_A[0] = restrictions_A[1] = restrictions_A[2] = INT_MAX;
	restrictions_B[0] = restrictions_B[1] = INT_MAX;
	
	switch( getRestriction( restriction ) )
	{
		case A1:
			restrictions_A[0] = getTransportationFromString( value );
			break;
		case A2:
			restrictions_A[1] = atoi( value );
			break;
		case A3:
			restrictions_A[2] = atoi( value );
			break;
		case B1:
			restrictions_B[0] = atoi( value );
			break;
		case B2:
			restrictions_B[1] = atoi( value );
			break;
		default:
			makeException( ERROR_CAMP_NOT_EXPECTED );
	}
	
	return;
}

int getTotalPrice( int * shortest_path_tree , Bridge ** bridges , int origin , int destination )
{
	int i , total_price = 0;
	
	for( i = destination ; i != origin ; i = shortest_path_tree[i] )
		total_price += getPrice( bridges[i] );
	
	return total_price;
}

int getTotalTime( int * shortest_path_tree , Bridge ** bridges , int origin , int destination )
{
	int total_time;
	
	if( origin == destination )
		return 0;
	
	total_time = getTotalTime( shortest_path_tree , bridges , origin , shortest_path_tree[destination] );
	
	return getTime( total_time % DAY_TIME , bridges[destination] ) + total_time;
}

int weigh( int counter , Item bridge , Item * efective_weight )
{
	int weight = INT_MAX;
	int i;
	LinkedList * aux;
	
	switch( optimization )
	{
		case TIME:
			for( aux = ( LinkedList * ) bridge ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
				if( ( ( i = getTime( counter , ( Bridge * ) getItemNode( aux ) ) ) < weight ) && 
					followRestrictionsA( ( Bridge * ) getItemNode( aux ) ) )
				{
					weight = i;
					( * efective_weight ) = ( Item ) getItemNode( aux );
				}
				
			break;
		case COST:		
			for( aux = ( LinkedList * ) bridge ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
				if( ( ( i = getPrice( ( Bridge * ) getItemNode( aux ) ) ) < weight ) && 
					followRestrictionsA( ( Bridge * ) getItemNode( aux ) ) )
				{
					weight = i;
					( * efective_weight ) = ( Item ) getItemNode( aux );
				}
				
			break;
		default:
			makeException( ERROR_UNKNOWN );
	}
	
	return weight;
}

int followRestrictionsA( Bridge * bridge )
{
	if( ( getTransportation( bridge ) != restrictions_A[0] ) && 
		( getDuration( bridge ) <= restrictions_A[1] ) &&
		( getPrice( bridge ) <= restrictions_A[2] ) )
		return 1;
	else
		return 0;
}

int followRestrictionsB( int weight )
{
	switch( optimization )
	{
		case TIME:
			return ( weight <= restrictions_B[0] ) ? 1 : 0;
		case COST:
			return ( weight <= restrictions_B[1] ) ? 1 : 0;
		default:
			makeException( ERROR_CAMP_NOT_EXPECTED );
	}
	
	return 0;
}

int getTime( int counter , Bridge * bridge )
{
	int total_time;
	int wait = 0;
	int clock_time , i;
	
	total_time = ready_from + counter;
	
	clock_time = total_time % DAY_TIME;
	
	do
	{
		if( clock_time > getNoMoreTravels( bridge ) )
		{
			wait += ( DAY_TIME - clock_time );
			clock_time = 0;
		}
	
		if( clock_time < getFirstTravel( bridge ) )
		{
			wait += getFirstTravel( bridge ) - clock_time;
			clock_time = getFirstTravel( bridge );
		}
	
		for( i = getFirstTravel( bridge ) ; i < clock_time ; i += getPeriod( bridge ) );
		
		wait += ( i <= DAY_TIME ) ? ( i - clock_time ) : ( DAY_TIME - clock_time );
		clock_time = ( i <= DAY_TIME ) ? i : 0;
	}
	while( clock_time > getNoMoreTravels( bridge ) || clock_time < getFirstTravel( bridge ) );
	
	return ( wait + getDuration( bridge ) );
}

void printPath( FILE * output_file , int * shortest_path_tree , Bridge ** bridges , int destination , int origin )
{
	if( destination == origin )
	{
		fprintf( output_file , "%d " , ( origin + 1 ) );
		return;
	}
	else
		printPath( output_file , shortest_path_tree , bridges , shortest_path_tree[destination] , origin );
	
	switch( getTransportation( bridges[destination] ) )
	{
		case PLANE:
			fprintf( output_file , "aviao " );
			break;
		case BOAT:
			fprintf( output_file , "barco " );
			break;
		case TRAIN:
			fprintf( output_file , "comboio " );
			break;
		case BUS:
			fprintf( output_file , "autocarro " );
			break;
		default:
			makeException( ERROR_CAMP_NOT_EXPECTED );
	}
	
	fprintf( output_file , "%d " , ( destination + 1 ) );
	
	return;
}

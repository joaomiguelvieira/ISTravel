#include <stdlib.h>
#include "Graph.h"

struct Graph_
{
	int vertices;
	int bridges;
	LinkedList ** adjacencies;
};

struct Link_
{
	int vertice;
	Item weight;
};

static void ( * freeWeight )( Item );

int getVertice( Link * link )
{
	return ( link -> vertice );
}

Item getWeight( Link * link )
{
	return ( link -> weight );
}

Link * newLink( int city , Item weight )
{
	Link * new;
	
	new = ( Link * ) malloc( sizeof( Link ) );
	if( new == ( Link * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
		
	( new -> vertice ) = city;
	( new -> weight ) = weight;
	
	return new;
}

Graph * graphInit( int vertices , int bridges , void ( * freeWeight_ )( Item ) )
{
	Graph * new;
	int i;
	
	new = ( Graph * ) malloc( sizeof( Graph ) );
	if( new == ( Graph * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	( new -> vertices ) = vertices;
	( new -> bridges ) = bridges;
	freeWeight = freeWeight_;
	
	( new -> adjacencies ) = ( LinkedList ** ) malloc( vertices * sizeof( LinkedList * ) );
	if( ( new -> adjacencies ) == ( LinkedList ** ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	for( i = 0 ; i < vertices ; i++ )
		( new -> adjacencies )[i] = initList();
	
	return new;
}

void graphLinkInsert( Graph * graph , int vertice1 , int vertice2 , Item weight )
{	
	( graph -> adjacencies )[vertice1] = insertUnsortedItemList( ( graph -> adjacencies )[vertice1] , ( Item ) newLink( vertice2 , weight ) );
	( graph -> adjacencies )[vertice2] = insertUnsortedItemList( ( graph -> adjacencies )[vertice2] , ( Item ) newLink( vertice1 , weight ) );
	
	return;
}

void freeGraph( Graph * graph )
{
	int i;
	LinkedList * aux;
	
	for( i = 0 ; i < ( graph -> vertices ) ; i++ )
	{	
		for( aux = ( graph -> adjacencies )[i] ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			if( ( ( ( Link * ) getItemNode( aux ) ) -> vertice ) < i )
				freeWeight( ( ( ( Link * ) getItemNode( aux ) ) -> weight ) );
		
		freeList( ( graph -> adjacencies )[ i ] , free );
	}
	
	free( graph -> adjacencies );
	free( graph );
	
	return;
}

#define VERTICE( A ) ( ( ( Link * ) getItemNode( A ) ) -> vertice )
#define WEIGHT( A , B ) weigh( weights[ A ] , B -> weight , &bridge )

static int * weights;

int * dijkstra( Graph * graph , int origin , int * shortest_path_tree , Item * bridges , int ( * weigh )( int , Item , Item * ) )
{
	int v , i;
	LinkedList * aux;
	Link * aux_node;
	Heap * priority_queue;
	int efective_weight;
	
	Item bridge;
	
	weights = ( int * ) malloc( ( graph -> vertices ) * sizeof( int ) );
	if( weights == ( int * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	priority_queue = NewHeap( ( graph -> vertices ) , weights );
	
	for( i = 0 ; i < ( graph -> vertices ) ; i++ )
	{
		shortest_path_tree[i] = -1;
		bridges[i] = ( Item ) NULL;
		weights[i] = INT_MAX;
		Direct_Insert( priority_queue , i );
	}
	
	weights[origin] = 0;
	
	incPriority( priority_queue , origin );
	
	/*printIntegersHeap( priority_queue );*/
	
	/*if( !verifyHeap( priority_queue ) )
	{
		printf( "ERROR!!!\n" );
		printIntegersHeap( priority_queue );
		for( a = 0 ; a < graph -> vertices ; a++ )
			printf( "%d " , weights[a] );
		printf( "\n" );
	}*/
	
	while( !isHeapEmpty( priority_queue ) )
	{			
		if( weights[ v = RemoveMax( priority_queue ) ] != INT_MAX )
		{	
			/*printf("here: %d\n" , v);*/
			for( aux = ( graph -> adjacencies )[ v ] ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			{
				
				aux_node = ( Link * ) getItemNode( aux );
				efective_weight = WEIGHT( v , aux_node );
				
				if( ( efective_weight != INT_MAX ) && ( weights[ i = ( aux_node -> vertice ) ] > weights[ v ] + efective_weight ) )
				{	
					bridges[i] = bridge;
					weights[i] = weights[ v ] + efective_weight;
					incPriority( priority_queue , i );
					shortest_path_tree[i] = v;
					
					/*if( !isHeapOrdered( priority_queue ) )
					{
						printf( "ERROR!!!\n" );
						printIntegersHeap( priority_queue );
						for( a = 0 ; a < graph -> vertices ; a++ )
							printf( "%d " , weights[a] );
						printf( "\n" );
					}*/
				}
			}
		}
	}
	
	FreeHeap( priority_queue );
	
	return weights;
}

#define ITEM_HEAP( A ) ( * ( int * ) A )

int compareWeights( Item vertice1 , Item vertice2 )
{	
	if( weights[ ITEM_HEAP( vertice1 ) ] > weights[ ITEM_HEAP( vertice2 ) ] )
		return 1;
	else
		return 0;	
}

void printInteger( Item integer )
{
	printf( "%d" , ITEM_HEAP( integer ) );
	
	return;
}

LinkedList * getAdjacencies( Graph * graph , int vertice )
{
	return ( graph -> adjacencies )[vertice];
}

int getNumberOfVertices( Graph * graph )
{
	return ( graph -> vertices );
}

void printGraph( Graph * graph )
{
	int i;
	LinkedList * aux;
	
	for( i = 0 ; i < graph -> vertices ; i++ )
	{
		printf( "[%d]: " , i );
		
		for( aux = ( graph -> adjacencies )[i] ; aux != ( LinkedList * ) NULL ; aux = getNextNodeList( aux ) )
			printf( "%d " , ( ( Link * ) getItemNode( aux ) ) -> vertice );
		
		printf( "\n" );
	}
}

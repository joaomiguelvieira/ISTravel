#include "Bridge.h"

struct Bridge_
{
	int transportation;
	int duration;
	int price;
	int first_travel;
	int no_more_travels;
	int period;
};

int getTransportation( Bridge * bridge )
{
	return ( bridge -> transportation );
}

int getDuration( Bridge * bridge )
{
	return ( bridge -> duration );
}

int getPrice( Bridge * bridge )
{
	return ( bridge -> price );
}

int getFirstTravel( Bridge * bridge )
{
	return ( bridge -> first_travel );
}

int getNoMoreTravels( Bridge * bridge )
{
	return ( bridge -> no_more_travels );
}

int getPeriod( Bridge * bridge )
{
	return ( bridge -> period );
}

Bridge * newBridge( int transportation , int duration , int price , int first_travel , int no_more_travels , int period )
{
	Bridge * new;
	
	new = ( Bridge * ) malloc( sizeof( Bridge ) );
	if( new == ( Bridge * ) NULL )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	( new -> transportation ) = transportation;
	( new -> duration ) = duration;
	( new -> price ) = price;
	( new -> first_travel ) = first_travel;
	( new -> no_more_travels ) = no_more_travels;
	( new -> period ) = period;
	
	return new;
}

void freeBridge( Item bridge )
{
	free( ( Bridge * ) bridge );
	
	return;
}

#include "Heap.h"

#define LESS( A , B ) ( ( h -> priority )[ A ] > ( h -> priority )[ B ] )

struct Heap_
{
	int * priority;
	int n_elements;
	int size;
	int * heapdata;
	int * positions;
};

void FixUp( Heap * h , int k )
{
	while ( ( k > 0 ) && LESS( ( h -> heapdata )[ ( k - 1 ) / 2 ] , ( h -> heapdata )[ k ] ) )
	{
		EXCH( ( h -> heapdata )[ k ] , ( h -> heapdata )[ ( k - 1 ) / 2 ] );
		EXCH( ( h -> positions )[ ( h -> heapdata )[ k ] ] , ( h -> positions )[ ( h -> heapdata )[ ( k - 1 ) / 2 ] ] );
		k = ( k - 1 ) / 2;
	}

	return;
}

void FixDown( Heap * h , int k )
{
	int j;

	while( ( 2 * k + 1 ) < ( h -> n_elements ) )
	{
		j = 2 * k + 1;
		
		if( ( ( j + 1 ) < ( h -> n_elements ) ) && LESS( ( h -> heapdata )[ j ] , ( h -> heapdata )[ j + 1 ] ) )
			j++;
		
		if( !LESS( ( h -> heapdata )[ k ] , ( h -> heapdata )[ j ] ) )
			break;
			
		EXCH( ( h -> heapdata )[ k ] , ( h -> heapdata )[ j ] );
		EXCH( ( h -> positions )[ ( h -> heapdata )[ k ] ] , ( h -> positions )[ ( h -> heapdata )[ j ] ] );
		k = j;
	}

	return;
}

Heap * NewHeap( int size , int * priority )
{
	Heap * h;

	h = ( Heap * ) malloc( sizeof( Heap ) );
	if( h == ( ( Heap * ) NULL ) )
		makeException( ERROR_MEMORY_ALLOCATION );

	( h -> n_elements ) = 0;
	( h -> priority ) = priority;
	( h -> size ) = size;

	( h -> heapdata ) = ( int * ) malloc( size * sizeof( int ) );
	if( ( h -> heapdata ) == ( ( int * ) NULL ) )
		makeException( ERROR_MEMORY_ALLOCATION );
	
	( h -> positions ) = ( int * ) malloc( size * sizeof( int ) );
	if( ( h -> positions ) == ( ( int * ) NULL ) )
		makeException( ERROR_MEMORY_ALLOCATION );

	return h;
}

void FreeHeap( Heap * h )
{
	free( h -> heapdata );
	free( h -> positions );
	free( h );
	
	return;
}

int Insert( Heap * h , int element )
{
	if( ( h -> n_elements ) == h -> size )
	{
		printf( "Heap full (size = %d) !\n" , h -> size );
		return 0;
	}
	
	( h -> heapdata )[ h -> n_elements ] = element;
	( h -> positions )[ element ] = ( h -> n_elements );

	h -> n_elements++;
	FixUp( h , h -> n_elements - 1 );

	return 1;
}

int Direct_Insert( Heap * h , int element )
{
	if( ( h -> n_elements ) == h -> size )
	{
		printf( "Heap full (size = %d) !\n" , h -> size );
		return 0;
	}

	( h -> heapdata )[ h -> n_elements ] = element;
	( h -> positions )[ element ] = ( h -> n_elements );

	h -> n_elements++;

	return 1;
}

void Modify( Heap * h , int index , int newvalue )
{
	if( index > ( ( h -> n_elements ) - 1 ) )
	{
		printf( "Index out of range (index = %d) !\n" , index );
		return;
	}
	
	if( LESS( newvalue , ( h -> heapdata )[ index ] ) )
	{
		( h -> heapdata )[ index ] = newvalue;
		FixDown( h , index );
	}
	else
	{
		( h -> heapdata )[ index ] = newvalue;
		FixUp( h , index );
	}

	return;
}

int RemoveMax( Heap * h )
{	
	int aux;
	
	if( ( h -> n_elements ) > 0 )
	{
		aux = ( h -> heapdata )[ 0 ];
		EXCH( ( h -> heapdata )[ 0 ] , ( h -> heapdata )[ ( h -> n_elements ) - 1 ] );
		( h -> n_elements )--;
		FixDown( h , 0 );
		return aux;
	}

	return -1;
}

void CleanHeap( Heap * h )
{	
	h -> n_elements = 0;
	
	return;
}

int VerifyHeap( Heap * h )
{
	int i;
	
	for( i = ( ( h -> n_elements ) - 1 ) ; i > 0 ; i-- )
		if( LESS( ( h -> heapdata )[ ( i - 1 ) / 2 ] , ( h -> heapdata )[i] ) )
			return 0;
	
	return 1;
}

void HeapSort( Heap * h )
{
	int backup = ( h -> n_elements );
	
	Heapify( h );
	
	while( h -> n_elements > 0 )
	{
		EXCH( ( h -> heapdata )[0] , ( h -> heapdata )[ ( h -> n_elements ) - 1 ] );
		
		( h -> n_elements )--;
		
		FixDown( h , 0 );
	}
	
	( h -> n_elements ) = backup;
	
	return;
}

void Heapify( Heap * h )
{
	int i;
	
	for( i = ( ( ( h -> n_elements ) - 1 ) / 2 ) ; i >= 0 ; i-- )
		FixDown( h , i );
	
	return;
}

int isHeapEmpty( Heap * heap )
{
	return ( heap -> n_elements == 0 ) ? 1 : 0;
}

void incPriority( Heap * heap , int index )
{
	FixUp( heap , ( heap -> positions )[ index ] );
	
	return;
}

#include <stdlib.h>
#include <stdio.h>
#include "Defs.h"

#define EXCH( A , B ) { int third; third = A; A = B; B = third; }

/* Criterium of comparation between two elements in the heap. */
#define LESS( A , B ) ( ( h -> priority )[ A ] > ( h -> priority )[ B ] )

typedef struct Heap_ Heap;

void cleanHeap( Heap * h );

int directInsert( Heap * h , int element );

void fixDown( Heap * h , int k );

void fixUp( Heap * h , int k );

void freeHeap( Heap * h );

void heapSort( Heap * h );

void heapify( Heap * h );

int insert( Heap * h , int element );

Heap * newHeap( int size , int * priority );

int removeMax( Heap * h );

int verifyHeap( Heap * h );

void incPriority( Heap * heap , int index );

int isHeapEmpty( Heap * heap );
